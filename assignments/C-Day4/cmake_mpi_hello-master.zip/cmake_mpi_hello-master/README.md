# CMake MPI

An MPI hello world example using CMake

## Steps
```
mkdir build && cd build
cmake ..
make
```
